package com.pavanzada.torus.figures;

import static com.pavanzada.torus.MyGLRenderer.c;
import static com.pavanzada.torus.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Cube {
    private static final int COORDS_PER_VERTEX = 3;
    private final FloatBuffer vertexBuffer;
    private final ShortBuffer shortBuffer;
    private final int vertexStride = COORDS_PER_VERTEX * 4;
    private final int mProgram;

    private int positionHandle;
    private int colorHandle;
    private int uMVPMatrixHandle;
    private final int vertexCount;

    float[] color = {c(0), c(149), c(80), 1.0f};

    public void setColor(float[] color) {
        this.color = color;
    }

    // Vertex coordinates for a cube (8 vertices, 3 coords each)
    private static final float[] coords = {
            // Front face
            -1.0f,  1.0f,  1.0f, // 0
            1.0f,  1.0f,  1.0f, // 1
            -1.0f, -1.0f,  1.0f, // 2
            1.0f, -1.0f,  1.0f, // 3
            // Back face
            -1.0f,  1.0f, -1.0f, // 4
            1.0f,  1.0f, -1.0f, // 5
            -1.0f, -1.0f, -1.0f, // 6
            1.0f, -1.0f, -1.0f  // 7
    };

    // Drawing order for the cube's triangles
    private static final short[] drawOrder = {
            // Front face
            0, 2, 1,  1, 2, 3,
            // Right face
            1, 3, 5,  5, 3, 7,
            // Back face
            5, 7, 4,  4, 7, 6,
            // Left face
            4, 6, 0,  0, 6, 2,
            // Top face
            4, 0, 5,  5, 0, 1,
            // Bottom face
            2, 6, 3,  3, 6, 7
    };

    public Cube() {
        ByteBuffer vb = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder());
        vertexBuffer = vb.asFloatBuffer();
        vertexBuffer.put(coords);
        vertexBuffer.position(0);

        ByteBuffer db = ByteBuffer.allocateDirect(drawOrder.length * 2).order(ByteOrder.nativeOrder());
        shortBuffer = db.asShortBuffer();
        shortBuffer.put(drawOrder);
        shortBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        vertexCount = drawOrder.length;
    }

    public void draw(float[] mVPMatriz) {
        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        uMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mVPMatriz, 0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, vertexCount, GLES20.GL_UNSIGNED_SHORT, shortBuffer);
        GLES20.glDisableVertexAttribArray(positionHandle);
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 aPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";
}
