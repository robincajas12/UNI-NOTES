package com.pavanzada.torus.figures;

import static com.pavanzada.torus.MyGLRenderer.c;
import static com.pavanzada.torus.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class TriangularPrism {
    private static final int COORDS_PER_VERTEX = 3;
    private final FloatBuffer vertexBuffer;
    private final ShortBuffer indexBuffer;
    private final int vertexStride = COORDS_PER_VERTEX * 4;
    private final int mProgram;

    private int positionHandle;
    private int colorHandle;
    private int uMVPMatrixHandle;
    private final int indexCount;

    float[] color = {c(200), c(100), c(200), 1.0f}; // violeta claro

    public void setColor(float[] color) {
        this.color = color;
    }

    // 6 vértices: triángulo superior y triángulo inferior
    private static final float[] coords = {
            // Triángulo superior (z = +1)
            0.0f,  1.0f, 1.0f,  // 0 - superior centro
            -1.0f, -1.0f, 1.0f,  // 1 - inferior izquierda
            1.0f, -1.0f, 1.0f,  // 2 - inferior derecha

            // Triángulo inferior (z = -1)
            0.0f,  1.0f, -1.0f, // 3
            -1.0f, -1.0f, -1.0f, // 4
            1.0f, -1.0f, -1.0f  // 5
    };

    // 8 caras: 2 triángulos + 3 rectángulos (2 triángulos cada uno)
    private static final short[] drawOrder = {
            // Caras triangulares (bases)
            0, 1, 2,    // superior
            3, 5, 4,    // inferior

            // Lateral 1: entre vértices 0,3 y 1,4
            0, 3, 1,
            1, 3, 4,

            // Lateral 2: entre vértices 1,4 y 2,5
            1, 4, 2,
            2, 4, 5,

            // Lateral 3: entre vértices 2,5 y 0,3
            2, 5, 0,
            0, 5, 3
    };

    public TriangularPrism() {
        ByteBuffer vb = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder());
        vertexBuffer = vb.asFloatBuffer();
        vertexBuffer.put(coords);
        vertexBuffer.position(0);

        ByteBuffer ib = ByteBuffer.allocateDirect(drawOrder.length * 2).order(ByteOrder.nativeOrder());
        indexBuffer = ib.asShortBuffer();
        indexBuffer.put(drawOrder);
        indexBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        indexCount = drawOrder.length;
    }

    public void draw(float[] mVPMatriz) {
        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        uMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mVPMatriz, 0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer);
        GLES20.glDisableVertexAttribArray(positionHandle);
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 aPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";
}
