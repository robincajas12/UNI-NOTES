package com.pavanzada.torus.utils;

import android.opengl.Matrix;

public class Transform {
    private final float[] matrix = new float[16];

    // Matrices temporales para cada transformación
    private final float[] scaleMatrix = new float[16];
    private final float[] rotateMatrix = new float[16];
    private final float[] translateMatrix = new float[16];

    private float scaleX = 1, scaleY = 1, scaleZ = 1;
    private float rotateAngle = 0;
    private float rotateX = 0, rotateY = 0, rotateZ = 1; // eje por defecto Z
    private float translateX = 0, translateY = 0, translateZ = 0;

    public Transform() {
        reset();
    }

    public Transform scaleAll(float v) {
        scaleX = v;
        scaleY = v;
        scaleZ = v;
        return this;
    }

    public Transform scale(float x, float y, float z) {
        scaleX = x;
        scaleY = y;
        scaleZ = z;
        return this;
    }

    public Transform translate(float x, float y, float z) {
        translateX = x;
        translateY = y;
        translateZ = z;
        return this;
    }

    public Transform rotate(float angle, float x, float y, float z) {
        rotateAngle = angle;
        rotateX = x;
        rotateY = y;
        rotateZ = z;
        return this;
    }

    public float[] getMatrix() {
        // Reiniciar matrices temporales a identidad
        Matrix.setIdentityM(scaleMatrix, 0);
        Matrix.setIdentityM(rotateMatrix, 0);
        Matrix.setIdentityM(translateMatrix, 0);

        // Crear matrices individuales
        Matrix.scaleM(scaleMatrix, 0, scaleX, scaleY, scaleZ);
        Matrix.rotateM(rotateMatrix, 0, rotateAngle, rotateX, rotateY, rotateZ);
        Matrix.translateM(translateMatrix, 0, translateX, translateY, translateZ);

        // Multiplicar en orden: TRASLADO * ROTACIÓN * ESCALA
        // (Primero escala, luego rota, luego traslada)

        float[] temp = new float[16];

        // rot * escala
        Matrix.multiplyMM(temp, 0, rotateMatrix, 0, scaleMatrix, 0);
        // translate * (rot * escala)
        Matrix.multiplyMM(matrix, 0, translateMatrix, 0, temp, 0);

        return matrix;
    }

    public void reset() {
        scaleX = scaleY = scaleZ = 1;
        rotateAngle = 0;
        rotateX = 0;
        rotateY = 0;
        rotateZ = 1;
        translateX = translateY = translateZ = 0;
        Matrix.setIdentityM(matrix, 0);
    }

    public float[] getMVP(float[] viewMatrix, float[] projectionMatrix) {
        float[] temp = new float[16];
        float[] mvp = new float[16];
        Matrix.multiplyMM(temp, 0, viewMatrix, 0, getMatrix(), 0);
        Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, temp, 0);
        return mvp;
    }
}

