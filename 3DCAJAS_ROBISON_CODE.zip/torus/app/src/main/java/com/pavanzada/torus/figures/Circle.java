package com.pavanzada.torus.figures;

import static com.pavanzada.torus.MyGLRenderer.c;
import static com.pavanzada.torus.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Circle {
    private static final int COORDS_PER_VERTEX = 3;
    private final FloatBuffer vertexBuffer;
    private final ShortBuffer shortBuffer;
    private final int vertexStride = COORDS_PER_VERTEX * 4;
    private final int mProgram;

    private int positionHandle;
    private int colorHandle;
    private int uMVPMatrixHandle;
    private int vertexCount;

    private float[] coords;
    private short[] drawOrder;

    static float[] color = {c(47), c(79), c(79), 1.0f};
    public void setColor(float[] color) {
        this.color = color;
    }
    private float[] scale = {1,1,1};
    private float[] translate = {0,0,0};
    private float[] rotate = {0,0,0};
    public Circle(int segments, float radius) {
        createCircle(segments, radius);

        ByteBuffer vb = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder());
        vertexBuffer = vb.asFloatBuffer();
        vertexBuffer.put(coords);
        vertexBuffer.position(0);

        ByteBuffer db = ByteBuffer.allocateDirect(drawOrder.length * 2).order(ByteOrder.nativeOrder());
        shortBuffer = db.asShortBuffer();
        shortBuffer.put(drawOrder);
        shortBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        vertexCount = drawOrder.length;
    }

    private void createCircle(int segments, float radius) {
        // +1 porque incluimos el centro
        coords = new float[(segments + 2) * 3];
        drawOrder = new short[segments * 3];

        // Centro
        coords[0] = 0.0f;
        coords[1] = 0.0f;
        coords[2] = 0.0f;

        // Puntos en la circunferencia
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (2 * Math.PI * i / segments);
            float x = (float) (radius * Math.cos(angle));
            float y = (float) (radius * Math.sin(angle));
            float z = 0.0f;

            coords[(i + 1) * 3 + 0] = x;
            coords[(i + 1) * 3 + 1] = y;
            coords[(i + 1) * 3 + 2] = z;
        }

        // Orden para formar triángulos en forma de abanico
        for (short i = 1; i <= segments; i++) {
            drawOrder[(i - 1) * 3 + 0] = 0;
            drawOrder[(i - 1) * 3 + 1] = i;
            drawOrder[(i - 1) * 3 + 2] = (short) (i == segments ? 1 : i + 1);
        }
    }

    public void draw(float[] mVPMatriz) {
        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        uMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mVPMatriz, 0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, vertexCount, GLES20.GL_UNSIGNED_SHORT, shortBuffer);
        GLES20.glDisableVertexAttribArray(positionHandle);
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 aPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";
}
