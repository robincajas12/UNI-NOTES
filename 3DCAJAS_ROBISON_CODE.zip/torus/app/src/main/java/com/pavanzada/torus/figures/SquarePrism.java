package com.pavanzada.torus.figures;

import static com.pavanzada.torus.MyGLRenderer.c;
import static com.pavanzada.torus.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class SquarePrism {
    private static final int COORDS_PER_VERTEX = 3;
    private final FloatBuffer vertexBuffer;
    private final ShortBuffer indexBuffer;
    private final int vertexStride = COORDS_PER_VERTEX * 4;
    private final int mProgram;

    private int positionHandle;
    private int colorHandle;
    private int mvpMatrixHandle;
    private final int indexCount;

    float[] color = {c(255), c(193), c(7), 1.0f}; // Ámbar

    public void setColor(float[] color) {
        this.color = color;
    }

    // Coordenadas para un prisma cuadrangular (8 vértices, como un cubo)
    private static final float[] vertices = {
            // Cara inferior
            -1.0f, -1.0f, -1.0f,  // 0
            1.0f, -1.0f, -1.0f,  // 1
            1.0f, -1.0f,  1.0f,  // 2
            -1.0f, -1.0f,  1.0f,  // 3
            // Cara superior
            -1.0f,  1.0f, -0.5f,  // 4
            1.0f,  1.0f, -0.5f,  // 5
            1.0f,  1.0f,  0.5f,  // 6
            -1.0f,  1.0f,  0.5f   // 7
    };

    // Índices para las caras (2 triángulos por cara)
    private static final short[] indices = {
            // Cara inferior
            0, 1, 2,  0, 2, 3,
            // Cara superior
            4, 6, 5,  4, 7, 6,
            // Lados
            0, 4, 5,  0, 5, 1,
            1, 5, 6,  1, 6, 2,
            2, 6, 7,  2, 7, 3,
            3, 7, 4,  3, 4, 0
    };

    public SquarePrism() {
        ByteBuffer vb = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder());
        vertexBuffer = vb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);

        ByteBuffer ib = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder());
        indexBuffer = ib.asShortBuffer();
        indexBuffer.put(indices);
        indexBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        indexCount = indices.length;
    }

    public void draw(float[] mvpMatrix) {
        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        mvpMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer);
        GLES20.glDisableVertexAttribArray(positionHandle);
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 aPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";
}

