package com.pavanzada.torus.figures;

import static com.pavanzada.torus.MyGLRenderer.c;
import static com.pavanzada.torus.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Cylinder {
    private static final int COORDS_PER_VERTEX = 3;
    private final FloatBuffer vertexBuffer;
    private final ShortBuffer indexBuffer;
    private final int vertexStride = COORDS_PER_VERTEX * 4;
    private final int mProgram;

    private int positionHandle;
    private int colorHandle;
    private int uMVPMatrixHandle;
    private final int indexCount;

    float[] color = {c(200), c(100), c(50), 1.0f};

    public void setColor(float[] color) {
        this.color = color;
    }

    public Cylinder(int segments, float radius, float height) {
        int verticesPerCircle = segments + 1;
        int totalVertices = verticesPerCircle * 2 + 2; // top, bottom circles + 2 centers
        float[] coords = new float[totalVertices * 3];
        short[] indices = new short[segments * 12]; // 6 for each quad + 3 for each center fan

        float halfHeight = height / 2.0f;
        int offset = 0;

        // Top and bottom circle vertices
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (2.0f * Math.PI * i / segments);
            float x = (float) Math.cos(angle) * radius;
            float z = (float) Math.sin(angle) * radius;

            // Top vertex
            coords[offset++] = x;
            coords[offset++] = halfHeight;
            coords[offset++] = z;

            // Bottom vertex
            coords[offset++] = x;
            coords[offset++] = -halfHeight;
            coords[offset++] = z;
        }

        // Center of top circle
        coords[offset++] = 0.0f;
        coords[offset++] = halfHeight;
        coords[offset++] = 0.0f;

        // Center of bottom circle
        coords[offset++] = 0.0f;
        coords[offset++] = -halfHeight;
        coords[offset++] = 0.0f;

        short topCenter = (short) (verticesPerCircle * 2);
        short bottomCenter = (short) (topCenter + 1);
        offset = 0;

        for (int i = 0; i < segments; i++) {
            short top1 = (short) (i * 2);
            short bottom1 = (short) (top1 + 1);
            short top2 = (short) ((i + 1) * 2 % (verticesPerCircle * 2));
            short bottom2 = (short) (top2 + 1);

            // Side quad (two triangles)
            indices[offset++] = top1;
            indices[offset++] = bottom1;
            indices[offset++] = top2;

            indices[offset++] = top2;
            indices[offset++] = bottom1;
            indices[offset++] = bottom2;

            // Top circle triangle
            indices[offset++] = top1;
            indices[offset++] = top2;
            indices[offset++] = topCenter;

            // Bottom circle triangle
            indices[offset++] = bottom2;
            indices[offset++] = bottom1;
            indices[offset++] = bottomCenter;
        }

        ByteBuffer vb = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder());
        vertexBuffer = vb.asFloatBuffer();
        vertexBuffer.put(coords);
        vertexBuffer.position(0);

        ByteBuffer ib = ByteBuffer.allocateDirect(indices.length * 2).order(ByteOrder.nativeOrder());
        indexBuffer = ib.asShortBuffer();
        indexBuffer.put(indices);
        indexBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);

        indexCount = indices.length;
    }

    public void draw(float[] mVPMatriz) {
        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "aPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);

        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        GLES20.glUniform4fv(colorHandle, 1, color, 0);

        uMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mVPMatriz, 0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer);
        GLES20.glDisableVertexAttribArray(positionHandle);
    }

    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 aPosition;" +
                    "void main() {" +
                    "  gl_Position = uMVPMatrix * aPosition;" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "void main() {" +
                    "  gl_FragColor = vColor;" +
                    "}";
}

