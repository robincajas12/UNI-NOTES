package com.pavanzada.torus;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import com.pavanzada.torus.figures.Circle;
import com.pavanzada.torus.figures.Cone;
import com.pavanzada.torus.figures.Cube;
import com.pavanzada.torus.figures.Cylinder;
import com.pavanzada.torus.figures.Torus;
import com.pavanzada.torus.figures.Triangle;
import com.pavanzada.torus.figures.TriangularPrism;
import com.pavanzada.torus.figures.TriangularPyramid;
import com.pavanzada.torus.utils.Colors;
import com.pavanzada.torus.utils.Transform;

import java.util.Random;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer{
    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];
    private final float[] modelMatrix = new float[16];
    private final float[] mvpMatrix = new float[16];
    Torus torus;
    Cube cube;
    Circle circle;
    Cylinder cylinder;
    TriangularPyramid triangle;
    Cone cone;
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {


        torus = new Torus(50,2.3f,0.2f);
        torus.setColor(Colors.mediumBlue);
        circle = new Circle(50,2);
        circle.setColor(Colors.lightSkyBlue);
        cube = new Cube();
        cube.setColor(Colors.gold);
        cylinder = new Cylinder(50,1,1);
        cylinder.setColor(Colors.coral);
        triangle = new TriangularPyramid();
        triangle.setColor(Colors.lightYellow);
        cone = new Cone();
        cone.setColor(Colors.darkOliveGreen);

    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0,0,width,height);
        GLES20.glClearColor(c(0), c(0), c(0), 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        float ratio = (float) width / height;
        Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1, 1, 3, 20);
    }
    public static float c(int v) { return v / 255f; }
    float a = 0;
    float b = 0;
    float[] coordsForAsteroid = new float[3];
    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.setLookAtM(viewMatrix, 0,
                0, 3, 15,
                0f, 0f, 0f,
                0f, 1f, 0f);
        Transform model = new Transform();


        model.reset();
        torus.draw(model
                .scaleAll(1f)
                .rotate(b, 1, 0, 0)
                .translate(0, 0f, 0f)
                .getMVP(viewMatrix, projectionMatrix));

        model.reset();
        circle.draw(model
                .scaleAll(1f)
                .translate(0, 0, 1)
                .getMVP(viewMatrix, projectionMatrix));

        model.reset();
        model.reset();
        cube.draw(model
                .scaleAll(0.1f)
                .translate(
                        3 * (float) Math.sin(a * 2 * Math.PI),
                        0.5f,
                        3 * (float) Math.cos(a * 2 * Math.PI))
                .getMVP(viewMatrix, projectionMatrix));

        model.reset();
        cylinder.draw(model
                .scaleAll(0.3f)
                .translate(
                        4 * (float) Math.cos(a * 2 * Math.PI),
                        4 * (float) Math.sin(a * 2 * Math.PI),
                        0.5f)
                .getMVP(viewMatrix, projectionMatrix));

        model.reset();
        triangle.draw(model
                .scaleAll(0.3f)
                .rotate(a * 1000, 0, 1, 0)
                .translate(
                        0.5f,
                        4 * (float) Math.sin(a * 3 * Math.PI),
                        4 * (float) Math.cos(a * 3 * Math.PI))
                .getMVP(viewMatrix, projectionMatrix));

        model.reset();
        cone.draw(model
                .scaleAll(0.3f)
                .rotate(a * 1000, 0, 1, 0)
                .translate(
                        (float) Math.tan(a * Math.PI),
                        4 * (float) Math.sin(a * 2 * Math.PI),
                        4 * (float) Math.cos(a * Math.PI))
                .getMVP(viewMatrix, projectionMatrix));

        a += 0.001f;
        b += 0.5f;
    }


        public static int loadShader(int type, String glShaderCode)
    {
        int shader= GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, glShaderCode);
        GLES20.glCompileShader(shader);
        int[] compileStatus = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0);
        if (compileStatus[0] == 0) {
            String error = GLES20.glGetShaderInfoLog(shader);
            GLES20.glDeleteShader(shader);
            throw new RuntimeException("Error compilando shader: " + error);
        }
        return shader;
    }
}
